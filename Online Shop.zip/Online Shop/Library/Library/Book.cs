﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Book : Form
    {
        public Book()
        {
            InitializeComponent();
            Random rnd = new Random();
            int rand = rnd.Next(0, 10000);
            label10.Text = Convert.ToString(rand);
        }
        string file;
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog image = new OpenFileDialog();
            image.InitialDirectory = @"C:\Users\NP\Desktop\هرگز پاک نشود\Pics";
            image.Filter = "image |*.png;*.jpg";

            if (image.ShowDialog() == DialogResult.OK)
            {
                file = image.FileName;
                pictureBox1.Image = Image.FromFile(file);
            }
        }
        string filepath1;
        private void button2_Click(object sender, EventArgs e)
        {
            string name = esm.Text;
            string nevisande = esmN.Text;
            string idGH = comboBox1.Text;
            string nasher = Nasher.Text;
            string price = pol.Text;
            string cod = code.Text;
            string id = label10.Text;
            string moj;
            if (radioButton1.Checked)
            {
                moj = radioButton1.Text;
            }
            else
            {
                moj = radioButton2.Text;
            }
            string time = Convert.ToString(DateTime.Today);
            string date = time.Substring(0, 10);
            filepath1 = @"C:\Users\NP\Desktop\هرگز پاک نشود\Book\"+ name + ".txt";
            string[] amir = { name + "\n" + nevisande + "\n" + idGH + "\n" + nasher + "\n" + price + "\n" + cod +"\n"+ id +"\n" + moj +"\n" +date+"\n" + file };
            File.WriteAllLines(filepath1, amir);

            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
