﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class afrad : Form
    {
        string[] amir;
      
        public afrad()
        {
            InitializeComponent();
             amir = Directory.GetFiles(Setting.path);
        }
        static string CreateMD5(string input)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                return Convert.ToBase64String(hashBytes);
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 aval = new Form1();
            aval.Show();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            string user = usernametext.Text;
            string pass = passwordtext.Text;
            string pass2 = CreateMD5(pass);
            foreach (var item in amir)
            {
                string tmp = item.Replace(Setting.path,"");
                string filename = tmp.Replace(".txt", "");

             
                
                if (user == filename)
                {
               string filepass =  Setting.getLineoffile(Setting.path + user + ".txt",1);
                    if (pass2 == filepass)
                    {


                        label5.Text = "Loading.... ";
                            timer1.Start();
                            PB.Enabled = true;
                        File.WriteAllText(Setting.path5 + "info.txt", usernametext.Text);

                     
                       
                    }
                    break;  
                }
                else
                {
                    MessageBox.Show("!اطلاعات وارد شده اشتباه است؟");
                    break;
                }

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (PB.Value == PB.Maximum)
            {
                timer1.Stop();
                this.Hide();
                AzaPanel aza = new AzaPanel();
                aza.Show();

            }
            if (PB.Value < PB.Maximum)
            {
                PB.Value++;
            }
        }
    }
}
