﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    
    public partial class modir : Form
    {
        string[] amir;
        public modir()
        {
            InitializeComponent();
           amir = File.ReadAllLines(@"F:\Library\Library\هرگز پاک نشود\the manager\modir.txt");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (usernametext.Text == amir[0] && passwordtext.Text == amir[1])
            {
                
                label5.Text = "Loading.... ";
                timer1.Start();
                PB.Enabled = true;

            }
            else
            {
                MessageBox.Show("!اطلاعات وارد شده اشتباه است؟");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (PB.Value == PB.Maximum)
            {
                timer1.Stop();
                this.Hide();
                Panel modir = new Panel();
                modir.Show();

            }
            if (PB.Value < PB.Maximum)
            {
                PB.Value++;
            }
        }

        private void PB_Click(object sender, EventArgs e)
        {
         
        }

        private void PB_BackColorChanged(object sender, EventArgs e)
        {
            PB.ForeColor = Color.Yellow;
        }

        private void modir_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 aval = new Form1();
           aval.Show();
        }
    }
}
