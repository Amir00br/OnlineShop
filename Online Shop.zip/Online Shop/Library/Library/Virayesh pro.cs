﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Virayeshpro : Form
    {
        public Virayeshpro()
        {
            InitializeComponent();
            InitializeComponent();
            for (int i = 0; i < 1; i++)
            {
                comboBox1.Items.Add("ایرانی");
                comboBox1.Items.Add("اتباع افغان");
                comboBox1.Items.Add("اتباع عراقی");


            }
            comboBox1.Text = "ملیت";
            for (int i = 0; i < 1; i++)
            {
                comboBox2.Items.Add("تهران");
                comboBox2.Items.Add("قم");
                comboBox2.Items.Add("تبریز");
                comboBox2.Items.Add("ارومیه");
                comboBox2.Items.Add("اهواز");
                comboBox2.Items.Add("خرم آباد");
                comboBox2.Items.Add("مشهد");
                comboBox2.Items.Add("ساری");
                comboBox2.Items.Add("قزوین");
                comboBox2.Items.Add("بوشهر");
                comboBox2.Items.Add("بندر عباس");
                comboBox2.Items.Add("اصفهان");
                comboBox2.Items.Add("شهر کرد");
                comboBox2.Items.Add("زاهدان");
                comboBox2.Items.Add("سنندج");
                comboBox2.Items.Add("شیراز");
            }
            comboBox2.Text = "شهر";


            Random rnd = new Random();
            int rand = rnd.Next(0, 10000);
            ID.Text = Convert.ToString(rand);


            string time = Convert.ToString(DateTime.Today);
        }
        static string CreateMD5(string input)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                return Convert.ToBase64String(hashBytes);
            }
        }

        private void Virayeshpro_Load(object sender, EventArgs e)
        {

        }

        private void Singel_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            sen.Text = trackBar1.Value + "";
        }
        string file;

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog image = new OpenFileDialog();
            image.InitialDirectory = @"C:\Users\NP\Desktop\هرگز پاک نشود\Pics";
            image.Filter = "image |*.png;*.jpg";

            if (image.ShowDialog() == DialogResult.OK)
            {
                file = image.FileName;
                pictureBox1.Image = Image.FromFile(file);
            }
        }
        string filepath1;
        private void Singup_Click(object sender, EventArgs e)
        {
            string name = fullname.Text;
            string emil = email.Text;
            string user1 = user.Text;
            string pass1 = pass.Text;
            string nation = comboBox1.Text;
            string city = comboBox2.Text;
            string jen;
            if (zan.Checked)
            {
                jen = zan.Text;
            }
            else
            {
                jen = mard.Text;
            }
            string singel;
            if (Singel.Checked)
            {
                singel = Singel.Text;
            }
            else
            {
                singel = "متاهل";
            }
            string Sen = Convert.ToString(trackBar1.Value);
            string Adres = adres.Text;
            string id = ID.Text;
            string time = Convert.ToString(DateTime.Today);
            string date = time.Substring(0, 10);

            string pass2 = CreateMD5(pass1);


            filepath1 = @"C:\Users\NP\Desktop\هرگز پاک نشود\Parts(اعضا)\" + user1 + ".txt";
            string[] amir = { user1 + "\n" + pass2 + "\n" + name + "\n" + file + "\n" + Sen + "\n" + emil + "\n" + singel + "\n" + jen + "\n" + Adres + "\n" + nation + "\n" + city + "\n" + id + "\n" + date };

            File.WriteAllLines(filepath1, amir);

            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }
    }
}
