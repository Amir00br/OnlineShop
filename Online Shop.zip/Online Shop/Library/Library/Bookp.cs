﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Bookp : Form
    {
        string[] d;
        public Bookp()
        {
            InitializeComponent();
            d = File.ReadAllLines(@"C:\Users\NP\Desktop\هرگز پاک نشود\info2.txt");
        }

        private void Bookp_Load(object sender, EventArgs e)
        {
            string[] a = File.ReadAllLines(Setting.path2 + d[0] + ".txt");

            name.Text += a[0];
            pictureBox1.Image = Image.FromFile(a[9]);
            nevi.Text += a[1];
            nasher.Text += a[3];
            ID.Text += a[6];
            pol.Text += a[4];

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AzaPanel v = new AzaPanel();
            v.Show();
        }
    }
}
