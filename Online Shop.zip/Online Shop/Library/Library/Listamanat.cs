﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Listamanat : Form
    {
        string[] amir2;
        public Listamanat()
        {
            InitializeComponent();
            amir2 = Directory.GetFiles(Setting.path4);
        }

        private void Listamanat_Load(object sender, EventArgs e)
        {
            foreach (var t in amir2)
            {
                string tmp2 = t.Replace(Setting.path4, "");
                string[] c = { tmp2.Replace(".txt", "") };

                listBox1.Items.Add(c[0]);
            }
        }
    }
}
