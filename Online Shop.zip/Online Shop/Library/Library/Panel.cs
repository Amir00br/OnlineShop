﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Panel : Form
    {
      
        public Panel()
        {
            InitializeComponent();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            modir modir = new modir();
            modir.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label5.Text = "Loading.... ";
            timer1.Start();
            PB.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (PB.Value == PB.Maximum)
            {
                timer1.Stop();
                this.Hide();
                Sapt sapt = new Sapt();
                sapt.Show();

            }
            if (PB.Value < PB.Maximum)
            {
                PB.Value++;
            }
        }

        private void مشاهدهلیستاعضاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 aza = new Form2();
            aza.Show();
            }

        private void قفسههاToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ویرایشقفسههاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Ghafase ketab = new Ghafase();
            ketab.Show();
        }

        private void ویرایشکتابهاToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void افزودنToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Book book = new Book();
            book.Show();
        }

        private void ویرایشToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            ویرایش virayesh = new ویرایش();
            virayesh.Show();
        }

        private void اماناتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Amanat ama = new Amanat();
            ama.Show();
        }

        private void مشاهدهلیستکتابهاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Listbook view = new Listbook();
            view.Show();
        }

        private void مشاهدهلیستقفسههاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Listghafase view = new Listghafase();
            view.Show();
        }

        private void لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Listamanat view = new Listamanat();
            view.Show();
        }

        private void لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Booklist view = new Booklist();
            view.Show();
        }

        private void ویرایشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Virayeshpro view = new Virayeshpro();
            view.Show();
        }

        private void حذفعضوToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete1 view = new Delete1();
            view.Show();
        }

        private void حذفکتابToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete2 view = new Delete2();
            view.Show();
        }

        private void حذفقفسهToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete3 view = new Delete3();
            view.Show();
        }
    }
    }

