﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
  
    public partial class AzaPanel : Form
    {
        string[] amir;
        string[] amir2;
        string[] d ;

        
        public AzaPanel()
        {
            InitializeComponent();
            amir = Directory.GetFiles(Setting.path);
            amir2 = Directory.GetFiles(Setting.path2);
           d = File.ReadAllLines(@"F:\Library\Library\هرگز پاک نشود\info.txt");
           
           

           






            foreach (var t in amir2)
            {
                string tmp2 = t.Replace(Setting.path2, "");
                string[] c = { tmp2.Replace(".txt", "") };

                listBox1.Items.Add(c[0]);
            }


        



        }

        private void prof_Click(object sender, EventArgs e)
        {
          

        foreach (var item in amir)
            {
                string tmp = item.Replace(Setting.path, "");
                string filename = tmp.Replace(".txt", "");
                
            }


            foreach (var t in amir2)
            {
                string tmp2 = t.Replace(Setting.path2, "");
                string[] c = { tmp2.Replace(".txt", "") };

                listBox1.Items.Add(c[0]);
            }
            Random rnd = new Random();
            int rand = rnd.Next(0, 10000);
            ID.Text = Convert.ToString(rand);



            for (int i = 0; i < 1; i++)
            {
                comboBox1.Items.Add("ایرانی");
                comboBox1.Items.Add("اتباع افغان");
                comboBox1.Items.Add("اتباع عراقی");


            }
            comboBox1.Text = "ملیت";
            for (int i = 0; i < 1; i++)
            {
                comboBox2.Items.Add("تهران");
                comboBox2.Items.Add("قم");
                comboBox2.Items.Add("تبریز");
                comboBox2.Items.Add("ارومیه");
                comboBox2.Items.Add("اهواز");
                comboBox2.Items.Add("خرم آباد");
                comboBox2.Items.Add("مشهد");
                comboBox2.Items.Add("ساری");
                comboBox2.Items.Add("قزوین");
                comboBox2.Items.Add("بوشهر");
                comboBox2.Items.Add("بندر عباس");
                comboBox2.Items.Add("اصفهان");
                comboBox2.Items.Add("شهر کرد");
                comboBox2.Items.Add("زاهدان");
                comboBox2.Items.Add("سنندج");
                comboBox2.Items.Add("شیراز");
            }
            comboBox2.Text = "شهر";
        }
        static string CreateMD5(string input)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                return Convert.ToBase64String(hashBytes);
            }
        }
        private void search_Click(object sender, EventArgs e)
        {

        }

        private void AzaPanel_Load(object sender, EventArgs e)
        {
            string[] a =File.ReadAllLines(  Setting.path + d[0] + ".txt" );
         
            name.Text += a[2];
        //    pictureBox1.Image = Image.FromFile(a[3]);
            gmail.Text += a[5];
            adres.Text += a[8];
            city.Text += a[9] + " - " +a[10];
            sen.Text += a[4];
            singel.Text += a[6];
            jen.Text += a[7];
           ID.Text += a[11];
           time.Text += a[12];


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = listBox1.FindString(textBox1.Text);
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Singup_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Singel_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }
        string filepath1;
        private void Singup_Click_1(object sender, EventArgs e)
        {
            string name = fullname.Text;
            string emil = email.Text;
            string user1 = user.Text;
            string pass1 = pass.Text;
            string pass2 = CreateMD5(pass1);
            string nation = comboBox1.Text;
            string id = ID.Text;

            filepath1 = @"C:\Users\NP\Desktop\هرگز پاک نشود\Parts(اعضا)\" + user1 + ".txt";
            string[] amir7 = { user1 + "\n" + pass2 + "\n" + name + "\n" + nation + "\n" + id + "\n" + emil };

            File.WriteAllLines(filepath1, amir7);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            File.WriteAllText(Setting.path5 + "info2.txt", listBox1.Text);

            this.Hide();
            Bookp modir = new Bookp();
            modir.Show();
        }

        private void vira_Click(object sender, EventArgs e)
        {

        }
    }
}
