﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Library
{
    class Setting
    {
        public static string path = @"F:\Library\Library\هرگز پاک نشود\Parts(اعضا)\";

        public static string getLineoffile(string path, int linnumber)
        {
            string[] alllines = File.ReadAllLines(path);
            return alllines[linnumber];
        }

        public static string path2 = @"F:\Library\Library\هرگز پاک نشود\Book\";
        public static string path3 = @"F:\Library\Library\هرگز پاک نشود\Ghafase\";
        public static string path4 = @"F:\Library\Library\هرگز پاک نشود\amanat\";
        public static string path5 = @"F:\Library\Library\هرگز پاک نشود\";



    }
}
