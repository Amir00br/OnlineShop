﻿namespace Library
{
    partial class Panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.مشاهدهلیستاعضاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حذفعضوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اماناتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.کتابهاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مشاهدهلیستکتابهاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشکتابهاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.افزودنToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.حذفکتابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قفسههاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مشاهدهلیستقفسههاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشقفسههاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حذفقفسهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.مدیریتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.سوابقاماناتاعضایکتابخانهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.PB = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button2.Location = new System.Drawing.Point(671, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(34, 34);
            this.button2.TabIndex = 8;
            this.button2.Text = "×";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Console", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Purple;
            this.label2.Location = new System.Drawing.Point(220, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(264, 37);
            this.label2.TabIndex = 11;
            this.label2.Text = "کتابخانه هنرستان رجایی";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button3.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(647, 33);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(58, 29);
            this.button3.TabIndex = 19;
            this.button3.Text = "back";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مشاهدهلیستاعضاToolStripMenuItem,
            this.ویرایشToolStripMenuItem,
            this.حذفعضوToolStripMenuItem,
            this.اماناتToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(52, 25);
            this.toolStripMenuItem1.Text = "اعضا";
            // 
            // مشاهدهلیستاعضاToolStripMenuItem
            // 
            this.مشاهدهلیستاعضاToolStripMenuItem.Name = "مشاهدهلیستاعضاToolStripMenuItem";
            this.مشاهدهلیستاعضاToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.مشاهدهلیستاعضاToolStripMenuItem.Text = "مشاهده لیست اعضا";
            this.مشاهدهلیستاعضاToolStripMenuItem.Click += new System.EventHandler(this.مشاهدهلیستاعضاToolStripMenuItem_Click);
            // 
            // ویرایشToolStripMenuItem
            // 
            this.ویرایشToolStripMenuItem.Name = "ویرایشToolStripMenuItem";
            this.ویرایشToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.ویرایشToolStripMenuItem.Text = "ویرایش";
            this.ویرایشToolStripMenuItem.Click += new System.EventHandler(this.ویرایشToolStripMenuItem_Click);
            // 
            // حذفعضوToolStripMenuItem
            // 
            this.حذفعضوToolStripMenuItem.Name = "حذفعضوToolStripMenuItem";
            this.حذفعضوToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.حذفعضوToolStripMenuItem.Text = "حذف عضو";
            this.حذفعضوToolStripMenuItem.Click += new System.EventHandler(this.حذفعضوToolStripMenuItem_Click);
            // 
            // اماناتToolStripMenuItem
            // 
            this.اماناتToolStripMenuItem.Name = "اماناتToolStripMenuItem";
            this.اماناتToolStripMenuItem.Size = new System.Drawing.Size(180, 26);
            this.اماناتToolStripMenuItem.Text = "امانات";
            this.اماناتToolStripMenuItem.Click += new System.EventHandler(this.اماناتToolStripMenuItem_Click);
            // 
            // کتابهاToolStripMenuItem
            // 
            this.کتابهاToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مشاهدهلیستکتابهاToolStripMenuItem,
            this.ویرایشکتابهاToolStripMenuItem,
            this.حذفکتابToolStripMenuItem});
            this.کتابهاToolStripMenuItem.Name = "کتابهاToolStripMenuItem";
            this.کتابهاToolStripMenuItem.Size = new System.Drawing.Size(62, 25);
            this.کتابهاToolStripMenuItem.Text = "کتاب ها";
            // 
            // مشاهدهلیستکتابهاToolStripMenuItem
            // 
            this.مشاهدهلیستکتابهاToolStripMenuItem.Name = "مشاهدهلیستکتابهاToolStripMenuItem";
            this.مشاهدهلیستکتابهاToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.مشاهدهلیستکتابهاToolStripMenuItem.Text = "مشاهده لیست کتاب ها";
            this.مشاهدهلیستکتابهاToolStripMenuItem.Click += new System.EventHandler(this.مشاهدهلیستکتابهاToolStripMenuItem_Click);
            // 
            // ویرایشکتابهاToolStripMenuItem
            // 
            this.ویرایشکتابهاToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.افزودنToolStripMenuItem,
            this.ویرایشToolStripMenuItem1});
            this.ویرایشکتابهاToolStripMenuItem.Name = "ویرایشکتابهاToolStripMenuItem";
            this.ویرایشکتابهاToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.ویرایشکتابهاToolStripMenuItem.Text = "ویرایش کتاب ها";
            this.ویرایشکتابهاToolStripMenuItem.Click += new System.EventHandler(this.ویرایشکتابهاToolStripMenuItem_Click);
            // 
            // افزودنToolStripMenuItem
            // 
            this.افزودنToolStripMenuItem.Name = "افزودنToolStripMenuItem";
            this.افزودنToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.افزودنToolStripMenuItem.Text = "افزودن";
            this.افزودنToolStripMenuItem.Click += new System.EventHandler(this.افزودنToolStripMenuItem_Click);
            // 
            // ویرایشToolStripMenuItem1
            // 
            this.ویرایشToolStripMenuItem1.Name = "ویرایشToolStripMenuItem1";
            this.ویرایشToolStripMenuItem1.Size = new System.Drawing.Size(120, 26);
            this.ویرایشToolStripMenuItem1.Text = "ویرایش";
            this.ویرایشToolStripMenuItem1.Click += new System.EventHandler(this.ویرایشToolStripMenuItem1_Click);
            // 
            // حذفکتابToolStripMenuItem
            // 
            this.حذفکتابToolStripMenuItem.Name = "حذفکتابToolStripMenuItem";
            this.حذفکتابToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.حذفکتابToolStripMenuItem.Text = "حذف کتاب";
            this.حذفکتابToolStripMenuItem.Click += new System.EventHandler(this.حذفکتابToolStripMenuItem_Click);
            // 
            // قفسههاToolStripMenuItem
            // 
            this.قفسههاToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مشاهدهلیستقفسههاToolStripMenuItem,
            this.ویرایشقفسههاToolStripMenuItem,
            this.حذفقفسهToolStripMenuItem});
            this.قفسههاToolStripMenuItem.Name = "قفسههاToolStripMenuItem";
            this.قفسههاToolStripMenuItem.Size = new System.Drawing.Size(62, 25);
            this.قفسههاToolStripMenuItem.Text = "قفسه ها";
            this.قفسههاToolStripMenuItem.Click += new System.EventHandler(this.قفسههاToolStripMenuItem_Click);
            // 
            // مشاهدهلیستقفسههاToolStripMenuItem
            // 
            this.مشاهدهلیستقفسههاToolStripMenuItem.Name = "مشاهدهلیستقفسههاToolStripMenuItem";
            this.مشاهدهلیستقفسههاToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.مشاهدهلیستقفسههاToolStripMenuItem.Text = "مشاهده لیست قفسه ها";
            this.مشاهدهلیستقفسههاToolStripMenuItem.Click += new System.EventHandler(this.مشاهدهلیستقفسههاToolStripMenuItem_Click);
            // 
            // ویرایشقفسههاToolStripMenuItem
            // 
            this.ویرایشقفسههاToolStripMenuItem.Name = "ویرایشقفسههاToolStripMenuItem";
            this.ویرایشقفسههاToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.ویرایشقفسههاToolStripMenuItem.Text = "ویرایش قفسه ها";
            this.ویرایشقفسههاToolStripMenuItem.Click += new System.EventHandler(this.ویرایشقفسههاToolStripMenuItem_Click);
            // 
            // حذفقفسهToolStripMenuItem
            // 
            this.حذفقفسهToolStripMenuItem.Name = "حذفقفسهToolStripMenuItem";
            this.حذفقفسهToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.حذفقفسهToolStripMenuItem.Text = "حذف قفسه";
            this.حذفقفسهToolStripMenuItem.Click += new System.EventHandler(this.حذفقفسهToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Lucida Console", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.کتابهاToolStripMenuItem,
            this.قفسههاToolStripMenuItem,
            this.مدیریتToolStripMenuItem});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.MdiWindowListItem = this.toolStripMenuItem1;
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(65, 500);
            this.menuStrip1.TabIndex = 21;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // مدیریتToolStripMenuItem
            // 
            this.مدیریتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem,
            this.لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem,
            this.سوابقاماناتاعضایکتابخانهToolStripMenuItem});
            this.مدیریتToolStripMenuItem.Name = "مدیریتToolStripMenuItem";
            this.مدیریتToolStripMenuItem.Size = new System.Drawing.Size(59, 25);
            this.مدیریتToolStripMenuItem.Text = "مدیریت";
            // 
            // لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem
            // 
            this.لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem.Name = "لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem";
            this.لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem.Text = "لیست کتاب های قرض داده شده در حال حاضر";
            this.لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem.Click += new System.EventHandler(this.لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem_Click);
            // 
            // لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem
            // 
            this.لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem.Name = "لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem";
            this.لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem.Text = "لیست کتاب های موجود در کتابخانه در حال حاضر";
            this.لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem.Click += new System.EventHandler(this.لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem_Click);
            // 
            // سوابقاماناتاعضایکتابخانهToolStripMenuItem
            // 
            this.سوابقاماناتاعضایکتابخانهToolStripMenuItem.Name = "سوابقاماناتاعضایکتابخانهToolStripMenuItem";
            this.سوابقاماناتاعضایکتابخانهToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.سوابقاماناتاعضایکتابخانهToolStripMenuItem.Text = "سوابق امانات اعضای کتابخانه";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Cyan;
            this.button1.Font = new System.Drawing.Font("Lucida Console", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Blue;
            this.button1.Location = new System.Drawing.Point(227, 189);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(257, 90);
            this.button1.TabIndex = 22;
            this.button1.Text = "ثبت نام اعضا";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PB
            // 
            this.PB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.PB.ForeColor = System.Drawing.Color.Yellow;
            this.PB.Location = new System.Drawing.Point(156, 359);
            this.PB.Name = "PB";
            this.PB.Size = new System.Drawing.Size(397, 23);
            this.PB.TabIndex = 23;
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(315, 403);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 16);
            this.label5.TabIndex = 24;
            // 
            // Panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(707, 500);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.PB);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Panel";
            this.Text = "Panel";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem مشاهدهلیستاعضاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حذفعضوToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem کتابهاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قفسههاToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem مشاهدهلیستکتابهاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشکتابهاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حذفکتابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مشاهدهلیستقفسههاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشقفسههاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حذفقفسهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مدیریتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لیستکتابهایقرضدادهشدهدرحالحاضرToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem لیستکتابهایموجوددرکتابخانهدرحالحاضرToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem سوابقاماناتاعضایکتابخانهToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar PB;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStripMenuItem اماناتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem افزودنToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشToolStripMenuItem1;
    }
}