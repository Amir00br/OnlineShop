﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Amanat : Form
    {
        string[] amir;
        string[] amir2;

        public Amanat()
        {
            InitializeComponent();
            amir = Directory.GetFiles(Setting.path);
            amir2 = Directory.GetFiles(Setting.path2);

            string time = Convert.ToString(DateTime.Today);
            string date = time.Substring(0, 10);
            label1.Text = date;



            foreach (var t in amir2)
            {
                string tmp2 = t.Replace(Setting.path2, "");
                string[] c = { tmp2.Replace(".txt", "") };
 
                listBox2.Items.Add(c[0]);
            //    listBox2.Items.Add(c[5] );
            }
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
      
        

        private void Amanat_Load(object sender, EventArgs e)
        {
       
            foreach (var item in amir)
            {
                string tmp = item.Replace(Setting.path, "");
                string[] r = { tmp.Replace(".txt", "") };
                listBox1.Items.Add(r[0]);





            }
            }






        string filepath1;
        private void button1_Click_2(object sender, EventArgs e)
        {
            string name = listBox1.Text;
            string user = listBox2.Text;
            string time = Convert.ToString(DateTime.Today);
            string date = time.Substring(0, 10);
            string time2 = textBox2.Text;

            filepath1 = @"F:\Library\Library\هرگز پاک نشود\amanat" + user + ".txt";
            string[] amir = { name + "\n" + user + "\n" + date + "\n" + time2 };
            File.WriteAllLines(filepath1, amir);
            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }
    }
}