﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Ghafase : Form
    {
        public Ghafase()
        {
            InitializeComponent();
            Random rnd = new Random();
            int rand = rnd.Next(0, 10000);
           label3.Text = Convert.ToString(rand);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        string filepath1;
        private void button1_Click(object sender, EventArgs e)
        {
            string name = esm.Text;
            string model = listBox1.Text;
            string time = Convert.ToString(DateTime.Today);
            string date = time.Substring(0, 10);
            string id = label3.Text;

            filepath1 = @"C:\Users\NP\Desktop\هرگز پاک نشود\Ghafase\" + model + ".txt";
            string[] amir = { name + "\n" + model + "\n" + id + "\n" + date };
            File.WriteAllLines(filepath1, amir);

            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }

        private void esm_TextChanged(object sender, EventArgs e)
        {

        }
      
        private void button1_Click_1(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox1.Text);
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }

        private void Ghafase_Load(object sender, EventArgs e)
        {

        }
    }
    }

