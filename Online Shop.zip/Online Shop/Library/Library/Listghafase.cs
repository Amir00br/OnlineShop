﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Listghafase : Form
    {
        string[] amir2;
        public Listghafase()
        {
            InitializeComponent();
            amir2 = Directory.GetFiles(Setting.path3);
        }

        private void Listghafase_Load(object sender, EventArgs e)
        {
            foreach (var t in amir2)
            {
                string tmp2 = t.Replace(Setting.path3, "");
                string[] c = { tmp2.Replace(".txt", "") };

                listBox1.Items.Add(c[0]);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = listBox1.FindString(textBox1.Text);
        }
    }
}
