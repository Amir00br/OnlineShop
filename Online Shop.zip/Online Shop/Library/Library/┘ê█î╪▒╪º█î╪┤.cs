﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class ویرایش : Form
    {
        public ویرایش()
        {
            InitializeComponent();
            Random rnd = new Random();
            int rand = rnd.Next(0, 10000);
            label11.Text = Convert.ToString(rand);
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
        string file;
      
        string filepath1;
        private void button2_Click(object sender, EventArgs e)
        {
            string name = esm.Text;
            string nevisande = esmN.Text;
            string idGH = comboBox1.Text;
            string nasher = Nasher.Text;
            string price = pol.Text;
            string cod = code.Text;
            string id = label11.Text;
            string moj;
            if (ast.Checked)
            {
                moj = ast.Text;
            }
            else
            {
                moj = nist.Text;
            }
            string time = Convert.ToString(DateTime.Today);

            filepath1 = @"C:\Users\NP\Desktop\هرگز پاک نشود\Book\" + name + ".txt";
            string[] amir = { name + "\n" + nevisande + "\n" + idGH + "\n" + nasher + "\n" + price + "\n" + cod + "\n" + id + "\n"+moj+"\n" + time };
            File.WriteAllLines(filepath1, amir);

            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog image = new OpenFileDialog();
            image.InitialDirectory = @"C:\Users\NP\Desktop\هرگز پاک نشود\Pics";
            image.Filter = "image |*.png;*.jpg";

            if (image.ShowDialog() == DialogResult.OK)
            {
                file = image.FileName;
                pictureBox1.Image = Image.FromFile(file);
            }
        }
    }
}
