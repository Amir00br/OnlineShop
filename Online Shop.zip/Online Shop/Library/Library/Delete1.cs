﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Delete1 : Form
    {
        public Delete1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string del = user.Text;


            File.Delete(Setting.path + del +".txt" );

            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }
    }
}
