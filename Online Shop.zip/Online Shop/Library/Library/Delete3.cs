﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Delete3 : Form
    {
        public Delete3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string del = user.Text;


            File.Delete(@"C:\Users\NP\Desktop\هرگز پاک نشود\Ghafase\" + del + ".txt");

            this.Hide();
            Panel modir = new Panel();
            modir.Show();
        }
    }
}
