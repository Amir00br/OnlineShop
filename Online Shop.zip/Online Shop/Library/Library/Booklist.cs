﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Booklist : Form
    {
        string[] amir2;
        public Booklist()
        {
            InitializeComponent();
            amir2 = Directory.GetFiles(Setting.path2);
        }

        private void Booklist_Load(object sender, EventArgs e)
        {
            foreach (var t in amir2)
            {
                string tmp2 = t.Replace(Setting.path2, "");
                string[] c = { tmp2.Replace(".txt", "") };

                listBox1.Items.Add(c[0]);
            }
        }
    }
}
