﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Form1 : Form
    {
     
        public Form1()
        {
            InitializeComponent();
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

       

        private void progressBar1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {

        }

        private void PB_BackColorChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            modir modir = new modir();
            modir.Show();
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            afrad aza = new afrad();
            aza.Show();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
          

            }
          
        }
    }

