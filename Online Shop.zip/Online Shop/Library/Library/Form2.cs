﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Library
{
    public partial class Form2 : Form
    {
        string[] amir;
        public Form2()
        {
            InitializeComponent();
            amir = Directory.GetFiles(Setting.path);
        }
        string[] r ;
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

            }

        private void Form2_Load(object sender, EventArgs e)
        {
           

         
            foreach (var item in amir)
            {
                string tmp = item.Replace(Setting.path, "");
                string[] r = { tmp.Replace(".txt", "") };
                
              
                listBox1.Items.Add(r[0]);




            }
        }
    }
}
