﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Cafe
{
    public partial class View_products : Form
    {
        public View_products()
        {
            InitializeComponent();
        }
        public class insert_products
        {
            public string product_name { get; set; }
            public string description { get; set; }
            public decimal price { get; set; }
            public string image { get; set; }
            public int category_id { get; set; }
    


        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Modir customers = new Modir();
            customers.Show();
        }

        private async void View_products_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string url = "http://127.0.0.1:5000/selectall_Products ";
            var httpResponse = await client.GetFromJsonAsync<List<insert_products>>(url);
            dataGridView1.DataSource = httpResponse;
        }
    }
}
