namespace Online_Cafe
{
    public partial class Hello : Form
    {
        public Hello()
        {
            InitializeComponent();
        }

        private void Admin_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login_admin Admin = new Login_admin();
            Admin.Show();
        }

        private void Customers_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login_customers customers = new Login_customers();
            customers.Show();

            
        }
    }
}