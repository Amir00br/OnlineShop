﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Online_Cafe.Insert_categories;

namespace Online_Cafe
{
    public partial class Update_categories : Form
    {
        public Update_categories()
        {
            InitializeComponent();
        }
        public class Update_Categories
        {
            public string category_name { get; set; }
            public string category_description { get; set; }
            public string category_image { get; set; }
            public string status { get; set; }


        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            string name = textBox3.Text;
            string desc = textBox4.Text;
            string image = file;
            string name2 = textBox1.Text;

            string url = "http://127.0.0.1:5000/Update_Categories?Cname=" + name2 + "&Cdescription=" + desc + "&Cimage=" + image + "&Cname=" + name;
            var httpResponse = await client.GetFromJsonAsync<insert_Categories>(url);
            if (httpResponse.status == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {
                MessageBox.Show("ثبت شد");
                this.Hide();
                Modir customers = new Modir();
                customers.Show();

            }
        }
        string file;
        private  void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog image = new OpenFileDialog();
            image.InitialDirectory = @"D:\PRO\image";
            image.Filter = "image |*.png;*.jpg";
            if (image.ShowDialog() == DialogResult.OK)
            {
                file = image.FileName;
                pictureBox1.Image = Image.FromFile(file);
            }
        }
    }
}
