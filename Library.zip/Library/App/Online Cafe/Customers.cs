﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Online_Cafe.Delete_categories;

namespace Online_Cafe
{
    public partial class Customers : Form
    {
        public Customers()
        {
            InitializeComponent();
        }

        private void settingToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        public class code
        {

            public string postal_code { get; set; }
            public string status { get; set; }
        }
        public class vi
        {
            public string frist_name { get; set; }

        }
        string amir;
        private async void Customers_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string url = "http://127.0.0.1:5000/prof_select ";
            var httpResponse = await client.GetFromJsonAsync<code>(url);
            amir = httpResponse.status;

            toolStripTextBox1.Text= "Hello " + amir;
            



        }

        private void categoriesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Browse browse = new Browse();
            browse.Show();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            

           
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            History browse = new History();
            browse.Show();
        }
    }
}
