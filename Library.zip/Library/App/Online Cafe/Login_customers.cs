﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Net.Http.Json;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static Online_Cafe.Create_customers;
using System.Security.Policy;

namespace Online_Cafe
{
    public partial class Login_customers : Form
    {
        public Login_customers()
        {
            InitializeComponent();
            textBox1.Select();
        }
        public class select_Customers
        {
            public string frist_name { get; set; }
            public string last_name { get; set; }
            public string email { get; set; }
            public string phone_number { get; set; }
            public string address { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postal_code { get; set; }
            public string status1 { get; set; }

        }
        public class v
        {
            public string frist_name { get; set; }
            public int customer_id { get; set; }

            public string status { get; set; }
        }
        public class v2
        {
           
            public int customer_id { get; set; }

            public string status { get; set; }
        }
        public class w
        {
            public int frist_name { get; set; }
            public string status { get; set; }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Create_customers customers= new Create_customers();
            customers.Show();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string postal = textBox2.Text;
            string name = textBox1.Text;   
            string url = "http://127.0.0.1:5000/select_Customers?code=" + postal;
            var httpResponse = await client.GetFromJsonAsync<select_Customers>(url);
            if (httpResponse.status1 == "success")
            {

              
                string url2 = "http://127.0.0.1:5000/prof?name=" + name;
                var httpResponse2 = await client.GetFromJsonAsync<v>(url2);
                if (httpResponse2.status == "success")
                {

                }
                else
                {
                    
                }
                

            }
            else
            {
                MessageBox.Show("!خطا");

               
            }
            string url7 = "http://127.0.0.1:5000/up_id?code=" + postal;
            string responseString8 = await client.GetStringAsync(url7);
            string[] list2 = responseString8.Split(",");
            string w = list2[0];

            string url9 = "http://127.0.0.1:5000/prof2?customer_id=" + w;
            var httpResponse9 = await client.GetFromJsonAsync<w>(url9);
            if (httpResponse9.status == "success")
            {

            }
            else
            {
                MessageBox.Show("خوش آمدید");
                this.Hide();
                Customers customers = new Customers();
                customers.Show();

            }

        }

        private void Login_customers_Load(object sender, EventArgs e)
        {

        }
    }
}
