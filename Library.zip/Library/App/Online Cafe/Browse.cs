﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Online_Cafe
{
    public partial class Browse : Form
    {
        public Browse()
        {
            InitializeComponent();
        }
        public class view
        {
            public string category_name { get; set; }
            public string product_name { get; set; }
           
       


            
        }
        private async void Browse_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string url = "http://127.0.0.1:5000/products_cate ";
            var httpResponse = await client.GetFromJsonAsync<List<view>>(url);
            dataGridView1.DataSource = httpResponse;

            string url4 = "http://127.0.0.1:5000/brow";

            string responseString = await client.GetStringAsync(url4);
            string[] list1 = responseString.Split(":");
            for (int i = 0; i < list1.Length; i++)
            {
                comboBox1.Items.Add(list1[i]);



            }
            







        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string name = comboBox1.Text;
            string url5 = "http://127.0.0.1:5000/showpro?product_name=" + name;

            string responseString2 = await client.GetStringAsync(url5);

            string[] list2 = responseString2.Split("-" );
            
            label1.Text= list2[0];
            label2.Text= list2[1];  
            label3.Text= list2[2];
            pictureBox1.Image = Image.FromFile(list2[3]);

            //MessageBox.Show(list2[0]);
            //MessageBox.Show(list2[1]);
            //MessageBox.Show(list2[2]);
            //MessageBox.Show(list2[3]);


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Order_customer customers = new Order_customer();
            customers.Show();
        }
    }
}
