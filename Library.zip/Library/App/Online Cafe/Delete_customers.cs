﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Online_Cafe
{
    public partial class Delete_customers : Form
    {
        public Delete_customers()
        {
            InitializeComponent();
        }
        public class Singup_customers
        {
            public string frist_name { get; set; }
            public string last_name { get; set; }
            public string email { get; set; }
            public string phone_number { get; set; }
            public string address { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postal_code { get; set; }
            public string status { get; set; }

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            string code = textBox1.Text;


            string url = "http://127.0.0.1:5000/Delete_Customers?code=" + code;
            var httpResponse = await client.GetFromJsonAsync<Singup_customers>(url);
            if (httpResponse.status == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {
                MessageBox.Show("ثبت شد");
                this.Hide();
                Modir customers = new Modir();
                customers.Show();

            }
        }
    }
}
