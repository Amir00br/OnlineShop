﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net.Http.Json;

namespace Online_Cafe
{
    public partial class Insert_categories : Form
    {
        public Insert_categories()
        {
            InitializeComponent();
        }
        public class insert_Categories
        {
            public string category_name { get; set; }
            public string category_description { get; set; }
            public string category_image { get; set; }
            public string status { get; set; }


        }
        string file;
        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog image = new OpenFileDialog();
            image.InitialDirectory = @"D:\PRO\image";
            image.Filter = "image |*.png;*.jpg";
            if (image.ShowDialog() == DialogResult.OK)
            {
                file = image.FileName;
                pictureBox1.Image = Image.FromFile(file);
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            string name = textBox3.Text;
            string desc = textBox4.Text;
            string image = file;

            string url = "http://127.0.0.1:5000/insert_Categories?Cname=" + name +"&Cdescription=" + desc + "&Cimage=" + image ;
            var httpResponse = await client.GetFromJsonAsync<insert_Categories>(url);
            if (httpResponse.status == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {
                MessageBox.Show("ثبت شد");
                this.Hide();
                Modir customers = new Modir();
                customers.Show();

            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
    }

