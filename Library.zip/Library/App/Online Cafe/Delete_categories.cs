﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Online_Cafe.Insert_categories;

namespace Online_Cafe
{
    public partial class Delete_categories : Form
    {
        public Delete_categories()
        {
            InitializeComponent();
        }
        public class Delete_Categories
        {
            public string category_name { get; set; }
            public string category_description { get; set; }
            public string category_image { get; set; }
            public string status { get; set; }


        }
        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string name2 = textBox1.Text;

            string url = "http://127.0.0.1:5000/Delete_Categories?Cname=" + name2;
            var httpResponse = await client.GetFromJsonAsync<Delete_Categories>(url);
            if (httpResponse.status == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {
                MessageBox.Show("ثبت شد");
                this.Hide();
                Modir customers = new Modir();
                customers.Show();

            }
        }
    }
}
