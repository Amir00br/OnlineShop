﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Online_Cafe.Update_order;

namespace Online_Cafe
{
    public partial class Delete_order : Form
    {
        public Delete_order()
        {
            InitializeComponent();
        }
        public class show
        {

            public int order_id { get; set; }
            public int customer_id { get; set; }

            public string frist_name { get; set; }
        }
        public class delete_order
        {

            
            public int customer_id { get; set; }

            public string status { get; set; }
        }
        public class delete_orderdet
        {


            public int order_id { get; set; }

            public string status { get; set; }
        }
        private async void Delete_order_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string url = "http://127.0.0.1:5000/delete_show ";
            var httpResponse = await client.GetFromJsonAsync<List<show>>(url);
            dataGridView1.DataSource = httpResponse;


        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            string customer =comboBox2.Text;
            string order = comboBox1.Text;



            string url = "http://127.0.0.1:5000/Delete_Orders?customer_id= " + customer;
            var httpResponse = await client.GetFromJsonAsync<delete_order>(url);
            if (httpResponse.status == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {



            }
            string url2 = "http://127.0.0.1:5000/Delete_Ordersdet?order_id= " + order;
            var httpResponse2 = await client.GetFromJsonAsync<delete_order>(url2);
            if (httpResponse2.status == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {
                MessageBox.Show("انجام شد");

                this.Hide();
                Modir customers = new Modir();
                customers.Show();


            }

        }
    }
}
