﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Online_Cafe.Delete_categories;

namespace Online_Cafe
{
    public partial class Delete_products : Form
    {
        public Delete_products()
        {
            InitializeComponent();
        }
        public class insert_products
        {
            public string product_name { get; set; }
            public string description { get; set; }
            public decimal price { get; set; }
            public string image { get; set; }
            public int category_id { get; set; }
            public string status { get; set; }


        }
        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string name2 = textBox1.Text;

            string url = "http://127.0.0.1:5000/Delete_Products?Pname=" + name2;
            var httpResponse = await client.GetFromJsonAsync<insert_products>(url);
            if (httpResponse.status == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {
                MessageBox.Show("ثبت شد");
                this.Hide();
                Modir customers = new Modir();
                customers.Show();

            }
        }
    }
}
