﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Cafe
{
    public partial class cart : Form
    {
        public cart()
        {
            InitializeComponent();
        }
        public class up
        {

            public string total_amount { get; set; }
            public int customer_id { get; set; }

            public string status1 { get; set; }

        }
        private async void cart_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();



            string url5 = "http://127.0.0.1:5000/show2";

            string responseString7 = await client.GetStringAsync(url5);

            string[] list2 = responseString7.Split(":");

            string q = list2[0];

            string url = "http://127.0.0.1:5000/up?id=" + q;

            string responseString1 = await client.GetStringAsync(url);

            string[] list = responseString1.Split(",");

            string w = list[0];
            label13.Text = w;



           
            



        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string url5 = "http://127.0.0.1:5000/show2";

            string responseString7 = await client.GetStringAsync(url5);

            string[] list2 = responseString7.Split(":");

            string q = list2[0];
            string r = "was paid";

            //string url = "http://127.0.0.1:5000/upsta?status=" + r +"&customer_id=" + q;
            //var httpResponse = await client.GetFromJsonAsync<up>(url);
            //if (httpResponse.status1 == "success")
            //{


            //}
            //else
            //{
            //    MessageBox.Show("تشکر از حسن انتخاب شما");
            //    this.Hide();
            //    Customers customers = new Customers();
            //    customers.Show();


            //}
            MessageBox.Show("تشکر از حسن انتخاب شما");
            this.Hide();
            Customers customers = new Customers();
            customers.Show();


        }
    }
}
