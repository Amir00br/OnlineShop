﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Net.Http.Json;


namespace Online_Cafe
{
    public partial class Login_admin : Form
    {
        public Login_admin()
        {
            InitializeComponent();
            textBox1.Select();
        }
        public class Admin
        {
            public string Username { get; set; }
            public string Password { get; set; }
            public string status { get; set; }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string user = textBox1.Text;
            string pass = textBox2.Text;

            string url = "http://127.0.0.1:5000/select_Admin?User=" + user + "&Pass=" + pass;
            var httpResponse = await client.GetFromJsonAsync<Admin>(url);
            if (httpResponse.status == "success")
            {
                MessageBox.Show("خوش آمدید");
                this.Hide();
                Modir m = new Modir();
                m.Show();
               
                
            }
            else
            {
                MessageBox.Show("!خطا");

            }

        }
    }
}
