﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Cafe
{
    public partial class Updata_products : Form
    {
        public Updata_products()
        {
            InitializeComponent();
        }
        public class category
        {

            public int category_id { get; set; }
            public string category_name { get; set; }





        }
        public class insert_products
        {
            public string product_name { get; set; }
            public string description { get; set; }
            public decimal price { get; set; }
            public string image { get; set; }
            public int category_id { get; set; }
            public string status { get; set; }


        }
        private async void Updata_products_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string url = "http://127.0.0.1:5000/selectall_Categories ";
            var httpResponse = await client.GetFromJsonAsync<List<category>>(url);
            dataGridView1.DataSource = httpResponse;

        }

        private async void button3_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            string name = textBox3.Text;
            string desc = textBox4.Text;
            string image = file;
            string price = textBox1.Text;
            string Cid = textBox2.Text;
            string name2 = textBox5.Text;
            string url = "http://127.0.0.1:5000/Update_Products?Pname=" + name2 + "&description=" + desc + "&price=" + price + "&image=" + image + "&Cid=" + Cid + "&Pname=" + name;
            var httpResponse = await client.GetFromJsonAsync<insert_products>(url);
            if (httpResponse.status == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {
                MessageBox.Show("ثبت شد");
                this.Hide();
                Modir customers = new Modir();
                customers.Show();

            }
        }
        string file;
        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog image = new OpenFileDialog();
            image.InitialDirectory = @"D:\PRO\image";
            image.Filter = "image |*.png;*.jpg";
            if (image.ShowDialog() == DialogResult.OK)
            {
                file = image.FileName;
                pictureBox1.Image = Image.FromFile(file);
            }
        }
    }
}
