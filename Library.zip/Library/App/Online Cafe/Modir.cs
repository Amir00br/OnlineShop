﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Cafe
{
    public partial class Modir : Form
    {
        public Modir()
        {
            InitializeComponent();
        }

        private void createToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            modir_customers customers = new modir_customers();
            customers.Show();
        }

        private void customersToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            view_customers customers = new view_customers();
            customers.Show();
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Update_customers customers = new Update_customers();
            customers.Show();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete_customers customers = new Delete_customers();
            customers.Show();
        }

        private void createToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Insert_categories customers = new Insert_categories();
            customers.Show();

        }

        private void updataToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Update_categories customers = new Update_categories();
            customers.Show();
        }

        private void deleteToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete_categories customers = new Delete_categories();
            customers.Show();
        }

        private void categoriesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            view_categories customers = new view_categories();
            customers.Show();
        }

        private void createToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Insert_Products customers = new Insert_Products();
            customers.Show();
        }

        private void updataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Updata_products customers = new Updata_products();
            customers.Show();

        }

        private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
           Delete_products customers = new Delete_products();
            customers.Show();
        }

        private void productsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            View_products customers = new View_products();
            customers.Show();
        }

        private void createToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Insert_orders customers = new Insert_orders();
            customers.Show();

        }

        private void ordersToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            History_admin customers = new History_admin();
            customers.Show();
        }

        private void updataToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Update_order customers = new Update_order();
            customers.Show();
        }

        private void deleteToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete_order customers = new Delete_order();
            customers.Show();
        }
    }
}
