﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Cafe
{
    public partial class view_categories : Form
    {
        public view_categories()
        {
            InitializeComponent();
        }
        public class category
        {
        
            public int category_id { get; set; }
            public string category_name { get; set; }
            public string category_description { get; set; }
            public string category_image { get; set; }




        }
       
       
        private async void view_categories_Load(object sender, EventArgs e)
        {
            
            HttpClient client = new HttpClient();

            string url = "http://127.0.0.1:5000/selectall_Categories ";
           var  httpResponse = await client.GetFromJsonAsync<List<category>>(url);
           
            dataGridView1.DataSource = httpResponse;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Modir customers = new Modir();
            customers.Show();
        }
    }
}
