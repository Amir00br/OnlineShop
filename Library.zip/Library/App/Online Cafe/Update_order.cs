﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Online_Cafe.Insert_categories;
using static Online_Cafe.Insert_orders;

namespace Online_Cafe
{
    public partial class Update_order : Form
    {
        public Update_order()
        {
            InitializeComponent();
        }
        public class Singup_customers
        {
            public int customer_id { get; set; }
            public string frist_name { get; set; }
            public string last_name { get; set; }
            public string email { get; set; }
            public string phone_number { get; set; }
            public string address { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postal_code { get; set; }


        }
        public class products
        {
            public int product_id { get; set; }
            public string product_name { get; set; }
            public string description { get; set; }
            public decimal price { get; set; }
            public string image { get; set; }
            public int category_id { get; set; }



        }
        public class up_order
        {
            public int customer_id { get; set; }
            public string order_date { get; set; }
            public string payment_type { get; set; }
            public decimal status { get; set; }
            public string status1 { get; set; }

        }
        public class up_orderdet
        {
            public int prodcuct_id { get; set; }
            public int quantity { get; set; }
            public string item_notes { get; set; }
            public decimal item_discount { get; set; }
            public string status1 { get; set; }

        }
        public class up
        {

            public string total_amount { get; set; }
            public int customer_id { get; set; }

            public string status1 { get; set; }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Modir customers = new Modir();
            customers.Show();
        }

        private async void Update_order_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string url = "http://127.0.0.1:5000/alCustomers ";
            var httpResponse = await client.GetFromJsonAsync<List<Singup_customers>>(url);
            dataGridView1.DataSource = httpResponse;

            string url2 = "http://127.0.0.1:5000/selectall_Products ";
            var httpResponse2 = await client.GetFromJsonAsync<List<products>>(url2);
            dataGridView2.DataSource = httpResponse2;

            string url4 = "http://127.0.0.1:5000/ss";

            string responseString = await client.GetStringAsync(url4);
            string[] list1 = responseString.Split(":");
            for (int i = 0; i < list1.Length; i++)
            {
                comboBox5.Items.Add(list1[i]);



            }
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string id = comboBox1.Text;
            string date = textBox1.Text;
            string type = comboBox2.Text;
            string status = textBox3.Text;
            string pric = comboBox5.Text;
            string id2 = comboBox3.Text;
            string tedad = comboBox4.Text;
            string note = textBox2.Text;
            string disc = textBox4.Text;
            string sta = textBox5.Text;

            string customerid = comboBox6.Text;
            string productid = comboBox7.Text;  
            string url = "http://127.0.0.1:5000/Update_Orders?customer_id=" + customerid + "&order_date=" + date + "&payment_type=" + type + "&status=" + status + "&customer_id=" + id;
            var httpResponse = await client.GetFromJsonAsync<up_order>(url);
            if (httpResponse.status1 == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {



            }
            string url2 = "http://127.0.0.1:5000/Update_Orderdet?product_id=" + productid + "&quantity=" + tedad + "&item_notes=" + note + "&item_discount=" + disc + "&item_price=" + pric + "&item_status=" + sta + "&product_id=" + id2;
            var httpResponse2 = await client.GetFromJsonAsync<up_orderdet>(url2);
            if (httpResponse2.status1 == "success")
            {

                MessageBox.Show("سفارش اشتباه است");
            }
            else
            {
                MessageBox.Show("ثبت شد");
                this.Hide();
                Insert_orders customers = new Insert_orders();
                customers.Show();


            }
            string url5 = "http://127.0.0.1:5000/up?id=" + id;

            string responseString7 = await client.GetStringAsync(url5);

            string[] list2 = responseString7.Split(",");

            string q = list2[0];
            label10.Text = q;

            string url4 = "http://127.0.0.1:5000/s";
            var httpResponse4 = await client.GetFromJsonAsync<insert_Categories>(url4);
            if (httpResponse4.status == "success")
            {

                MessageBox.Show("خطا در ثبت سفارش");
            }
            else
            {



            }
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string u = label10.Text;
            string p = comboBox1.Text;
            string url10 = "http://127.0.0.1:5000/ordertotal?total=" + u + "&id=" + p;
            var httpResponse10 = await client.GetFromJsonAsync<up>(url10);
            if (httpResponse10.status1 == "success")
            {


            }
            else
            {
                MessageBox.Show("سفارش شما ثبت شد");
                this.Hide();
                Modir customers = new Modir();
                customers.Show();


            }
        }

        private async void button4_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string id3 = comboBox1.Text;

            string url5 = "http://127.0.0.1:5000/up?id=" + id3;

            string responseString7 = await client.GetStringAsync(url5);

            string[] list2 = responseString7.Split(",");

            string q = list2[0];
            label10.Text = q;
        }
    }
}
