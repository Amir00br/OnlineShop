﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Online_Cafe.Create_customers;

namespace Online_Cafe
{
    public partial class modir_customers : Form
    {
        public modir_customers()
        {
            InitializeComponent();
        }
        public class Singup_customers2
        {
            public string frist_name { get; set; }
            public string last_name { get; set; }
            public string email { get; set; }
            public string phone_number { get; set; }
            public string address { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postal_code { get; set; }
            public string status { get; set; }

        }
        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string fname = textBox1.Text;
            string lname = textBox2.Text;
            string number = textBox3.Text;
            string adres = textBox4.Text;
            string city = textBox5.Text;
            string email = textBox6.Text;
            string postal = textBox7.Text;
            string state = comboBox1.Text;

            string url = "http://127.0.0.1:5000/insert_Customers?Fname=" + fname + "&Lname=" + lname + "&email=" + email + "&phone=" + number + "&address=" + adres + "&city=" + city + "&state=" + state + "&code=" + postal;
            var httpResponse = await client.GetFromJsonAsync<Singup_customers2>(url);
            if (httpResponse.status == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {
                MessageBox.Show("ثبت شد");
                this.Hide();
                Modir customers = new Modir();
                customers.Show();

            }
        }
    }
    }

