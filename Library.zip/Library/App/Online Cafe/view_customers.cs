﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Online_Cafe.modir_customers;

namespace Online_Cafe
{
    public partial class view_customers : Form
    {
        public view_customers()
        {
            InitializeComponent();
        }
        public class Singup_customers
        {
            public string frist_name { get; set; }
            public string last_name { get; set; }
            public string email { get; set; }
            public string phone_number { get; set; }
            public string address { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postal_code { get; set; }
          

        }
        private async void view_customers_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string url = "http://127.0.0.1:5000/alCustomers ";
            var httpResponse = await client.GetFromJsonAsync<List<Singup_customers>>(url);
            dataGridView1.DataSource = httpResponse;
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Modir customers = new Modir();
            customers.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
