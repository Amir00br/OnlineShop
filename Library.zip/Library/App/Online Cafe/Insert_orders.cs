﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;
using static Online_Cafe.Insert_categories;

namespace Online_Cafe
{
    public partial class Insert_orders : Form
    {
        public  Insert_orders()
        {
            InitializeComponent();

            

           
        }
        public class Singup_customers
        {
            public int customer_id { get; set; }
            public string frist_name { get; set; }
            public string last_name { get; set; }
            public string email { get; set; }
            public string phone_number { get; set; }
            public string address { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postal_code { get; set; }


        }
        public class products
        {
            public int product_id { get; set; }
            public string product_name { get; set; }
            public string description { get; set; }
            public decimal price { get; set; }
            public string image { get; set; }
            public int category_id { get; set; }



        }
        public class insert_order
        {
            public int customer_id { get; set; }
            public string order_date { get; set; }
            public string payment_type { get; set; }
            public decimal status { get; set; }
            public string status1 { get; set; }

        }
        public class insert_orderdet
        {
            public int prodcuct_id { get; set; }
            public int quantity { get; set; }
            public string item_notes { get; set; }
            public decimal item_discount { get; set; }
            public string status1 { get; set; }

        }
        public class up
        {
           
            public string total_amount { get; set; }
            public int customer_id { get; set; }

            public string status1 { get; set; }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Modir customers = new Modir();
            customers.Show();
        }

        private async void Insert_orders_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string url = "http://127.0.0.1:5000/alCustomers ";
            var httpResponse = await client.GetFromJsonAsync<List<Singup_customers>>(url);
            dataGridView1.DataSource = httpResponse;

            string url2 = "http://127.0.0.1:5000/selectall_Products ";
            var httpResponse2 = await client.GetFromJsonAsync<List<products>>(url2);
            dataGridView2.DataSource = httpResponse2;



            string url4 = "http://127.0.0.1:5000/ss";

            string responseString = await client.GetStringAsync(url4);
            string[] list1 = responseString.Split(":");
            for (int i = 0; i < list1.Length; i++)
            {
                comboBox5.Items.Add( list1[i]);



            }
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            string id =  comboBox1.Text;
            string date = textBox1.Text;
            string type = comboBox2.Text;
            string status = textBox3.Text;
            string pric = comboBox5.Text;
            string id2 = comboBox3.Text;
            string tedad = comboBox4.Text;
            string note = textBox2.Text;
            string disc = textBox4.Text;
            string sta = textBox5.Text;
            string url = "http://127.0.0.1:5000/insert_Orders?customer_id=" + id + "&order_date=" + date  + "&payment_type=" + type + "&status=" + status ;
            var httpResponse = await client.GetFromJsonAsync<insert_order>(url);
            if (httpResponse.status1 == "success")
            {

                MessageBox.Show("!خطا");
            }
            else
            {
                
                

            }
            string url2 = "http://127.0.0.1:5000/order_det?product_id=" + id2 + "&quantity=" + tedad + "&item_notes=" + note + "&item_discount=" + disc + "&item_price=" + pric + "&item_status=" + sta;
            var httpResponse2 = await client.GetFromJsonAsync<insert_orderdet>(url2);
            if (httpResponse2.status1 == "success")
            {

                MessageBox.Show("سفارش اشتباه است");
            }
            else
            {
                MessageBox.Show("ثبت شد");
                this.Hide();
                Insert_orders customers = new Insert_orders();
                customers.Show();


            }
            string url5 = "http://127.0.0.1:5000/up?id=" + id;

            string responseString7 = await client.GetStringAsync(url5);

            string[] list2 = responseString7.Split(",");

            string q = list2[0];
            label10.Text = q;


            string url4 = "http://127.0.0.1:5000/s";
            var httpResponse4 = await client.GetFromJsonAsync<insert_Categories>(url4);
            if (httpResponse4.status == "success")
            {

                MessageBox.Show("خطا در ثبت سفارش");
            }
            else
            {
               


            }

            







        }

        private async void button3_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();
            string u = label10.Text;
            string p =  comboBox1.Text;
            string url10 = "http://127.0.0.1:5000/ordertotal?total=" + u + "&id=" + p ;
            var httpResponse10 = await client.GetFromJsonAsync<up>(url10);
            if (httpResponse10.status1 == "success")
            {


            }
            else
            {
                MessageBox.Show("سفارش شما ثبت شد");
                this.Hide();
                Modir customers = new Modir();
                customers.Show();


            }

           




        }

        private async void button4_Click(object sender, EventArgs e)
        {

            HttpClient client = new HttpClient();

            string id3 = comboBox1.Text;

            string url5 = "http://127.0.0.1:5000/up?id=" + id3;

            string responseString7 = await client.GetStringAsync(url5);

            string[] list2 = responseString7.Split(",");

            string q = list2[0];
            label10.Text = q;
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
