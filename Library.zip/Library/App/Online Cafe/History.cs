﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Json;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Cafe
{
    public partial class History : Form
    {
        public History()
        {
            InitializeComponent();
        }
        public class show
        {
            public int order_id { get; set; }
            public int customer_id { get; set; }
            public string frist_name { get; set; }
            public string phone_number { get; set; }
            public string order_date { get; set; }
            public int total_amount { get; set; }
            public int quantity { get; set; }
            public string product_name { get; set; }



        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customers customers = new Customers();
            customers.Show();
        }

        private async void History_Load(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

           
            string url5 = "http://127.0.0.1:5000/show2";

            string responseString7 = await client.GetStringAsync(url5);

            string[] list2 = responseString7.Split(":");

            string q = list2[0];

            string url = "http://127.0.0.1:5000/select_Orders?customer_id= " + q;
            var httpResponse = await client.GetFromJsonAsync<List<show>>(url);
            dataGridView1.DataSource = httpResponse;


        }
    }
}
