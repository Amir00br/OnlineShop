from flask import Flask
from flask import request
import json

import sqlite3

app = Flask(__name__)

# FEATURES FOR ADMIN

# Customers

@app.route('/insert_Customers', methods=['GET'])
def insert_Customers():
     #query parameters
    frist_name = request.args.get('Fname')
    last_name = request.args.get('Lname')
    email     = request.args.get('email')
    phone_number     = request.args.get('phone')
    address          = request.args.get('address')
    city          = request.args.get('city')
    state          = request.args.get('state')
    postal_code         = request.args.get('code')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("INSERT INTO Customers(frist_name,last_name,email,phone_number,address,city,state,postal_code) VALUES ('"+frist_name+"','"+last_name+"','"+email +"','"+ phone_number+"','"+address +"','"+city+"','"+state+"','"+postal_code+"')")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "frist_name": row[1],
            "last_name": row[2],
            "email": row[3],
            "phone_number": row[4],
            "address": row[5],
            "city": row[6],
            "state": row[7],
            "postal_code": row[8],

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response
 
@app.route('/Update_Customers', methods=['GET'])
def Update_Customers():
     #query parameters
    frist_name = request.args.get('Fname')
    last_name = request.args.get('Lname')
    email     = request.args.get('email')
    phone_number     = request.args.get('phone')
    address          = request.args.get('address')
    city          = request.args.get('city')
    state          = request.args.get('state')
    postal_code         = request.args.get('code')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("UPDATE Customers  SET frist_name ='"+frist_name+"' ,last_name='"+last_name+"' ,email='"+email +"' ,phone_number='"+ phone_number+"' ,address='"+address +"' ,city='"+city+"' ,state='"+state+"' ,postal_code='"+postal_code+"' where postal_code='"+postal_code+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "frist_name": row[1],
            "last_name": row[2],
            "email": row[3],
            "phone_number": row[4],
            "address": row[5],
            "city": row[6],
            "state": row[7],
            "postal_code": row[8],

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response

    

@app.route('/Delete_Customers', methods=['GET'])
def Delete_Customers():
     #query parameters
    frist_name = request.args.get('Fname')
    last_name = request.args.get('Lname')
    email     = request.args.get('email')
    phone_number     = request.args.get('phone')
    address          = request.args.get('address')
    city          = request.args.get('city')
    state          = request.args.get('state')
    postal_code         = request.args.get('code')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("DELETE FROM Customers WHERE  postal_code='"+postal_code+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "frist_name": row[1],
            "last_name": row[2],
            "email": row[3],
            "phone_number": row[4],
            "address": row[5],
            "city": row[6],
            "state": row[7],
            "postal_code": row[8],

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response

@app.route('/select_Customers', methods=['GET'])
def select_Customers():
     #query parameters
    frist_name = request.args.get('Fname')
    last_name = request.args.get('Lname')
    email     = request.args.get('email')
    phone_number     = request.args.get('phone')
    address          = request.args.get('address')
    city          = request.args.get('city')
    state          = request.args.get('state')
    postal_code         = request.args.get('code')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select * from Customers where postal_code ='"+postal_code+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "frist_name": row[1],
            "last_name": row[2],
            "email": row[3],
            "phone_number": row[4],
            "address": row[5],
            "city": row[6],
            "state": row[7],
            "postal_code": row[8],

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response



    

@app.route('/alCustomers', methods=['GET'])
def alCustomers():
    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select * from Customers")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "frist_name": row[1],
            "last_name": row[2],
            "email": row[3],
            "phone_number": row[4],
            "address": row[5],
            "city": row[6],
            "state": row[7],
            "postal_code": row[8],

        }
        mylist.append(mydict)
    return mylist





@app.route('/amir', methods=['GET'])
def amir():
     #query parameters
    frist_name = request.args.get('Fname')
    last_name = request.args.get('Lname')
    email     = request.args.get('email')
    phone_number     = request.args.get('phone')
    address          = request.args.get('address')
    city          = request.args.get('city')
    state          = request.args.get('state')
    postal_code         = request.args.get('code')
   
   


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("DELETE FROM Customers WHERE postal_code ='"+postal_code +"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "frist_name": row[1],
            "last_name": row[2],
            "email": row[3],
            "phone_number": row[4],
            "address": row[5],
            "city": row[6],
            "state": row[7],
            "postal_code": row[8],


           

        }
        mylist.append(mydict)

        print(mylist) 
    response = {"status": row[1]}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response


# products


@app.route('/insert_Products', methods=['GET'])
def insert_Products():
     #query parameters
    product_name = request.args.get('Pname')
    description = request.args.get('description')
    price     = request.args.get('price')
    image     = request.args.get('image')
    category_id = request.args.get('Cid')
   


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("INSERT INTO Products(product_name,description,price,image,category_id) VALUES ('"+product_name+"','"+ description+"','"+price +"','"+image +"','"+category_id+"')")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "products_name":row[0],
            "description": row[1],
            "price": row[2],
            "image": row[3],
            "category_id": row[4],

           

        }
        mylist.append(mydict)

        print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response

@app.route('/select_Products', methods=['GET'])
def select_Products():
     #query parameters
    product_name = request.args.get('Pname')
    description = request.args.get('description')
    price     = request.args.get('price')
    image     = request.args.get('image')
   
   


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select * from Products where product_name ='"+product_name+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "product_name":row[0],
            "description": row[1],
            "price": row[2],
            "image": row[3],
           

        }
        mylist.append(mydict)

    return mylist

@app.route('/selectall_Products', methods=['GET'])
def selectall_Products():
     #query parameters
    product_name = request.args.get('Pname')
    description = request.args.get('description')
    price     = request.args.get('price')
    image     = request.args.get('image')
   
   


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select * from Products")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "product_id":row[0],
            "product_name":row[1],
            "description": row[2],
            "price": row[3],
            "image": row[4],
            "category_id": row[5], 

        }
        mylist.append(mydict)

    return mylist


@app.route('/Update_Products', methods=['GET'])
def Update_Products():
     #query parameters
    product_name = request.args.get('Pname')
    description = request.args.get('description')
    price     = request.args.get('price')
    image     = request.args.get('image')
   
   


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("UPDATE Products  SET product_name ='"+product_name+"' ,description='"+description+"' , price='"+ price +"', image  ='"+ image  +"'where product_name ='"+product_name+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "product_name":row[0],
            "description": row[1],
            "price": row[2],
            "image": row[3],
            "category_id": row[4],

           

        }
        mylist.append(mydict)

        print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response
    


@app.route('/Delete_Products', methods=['GET'])
def Delete_Products():
     #query parameters
    product_name = request.args.get('Pname')
    description = request.args.get('description')
    price     = request.args.get('price')
    image     = request.args.get('image')
   
   


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("DELETE FROM Products WHERE  product_name='"+product_name+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "product_name":row[0],
            "description": row[1],
            "price": row[2],
            "image": row[3],
            "category_id": row[4],

           

        }
        mylist.append(mydict)

        print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response
    


# Categories

@app.route('/insert_Categories', methods=['GET'])
def insert_Categories():
     #query parameters
    category_name = request.args.get('Cname')
    category_description = request.args.get('Cdescription')
    category_image    = request.args.get('Cimage')
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("INSERT INTO Categories(category_name,category_description,category_image) VALUES ('"+category_name+"','"+category_description+"','"+category_image +"')")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "category_name":row[0],
            "category_description": row[1],
            "category_image": row[2],
    

           

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response



@app.route('/select_Categories', methods=['GET'])
def select_Categories():
     #query parameters
    category_name = request.args.get('Cname')
    category_description = request.args.get('Cdescription')
    category_image    = request.args.get('Cimage')
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select * from Categories where category_name ='"+category_name+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "category_name":row[0],
            "category_description": row[1],
            "category_image": row[2],
    

           

        }
        mylist.append(mydict)

    return mylist


@app.route('/selectall_Categories', methods=['GET'])
def selectall_Categories():
     #query parameters
    category_name = request.args.get('Cname')
    category_description = request.args.get('Cdescription')
    category_image    = request.args.get('Cimage')
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select * from Categories ")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "category_id":row[0],
            "category_name":row[1],
            "category_description": row[2],
            "category_image": row[3],
    

           

        }
        mylist.append(mydict)

    return mylist

  

@app.route('/Update_Categories', methods=['GET'])
def Update_Categories():
     #query parameters
    category_name = request.args.get('Cname')
    category_description = request.args.get('Cdescription')
    category_image    = request.args.get('Cimage')
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("UPDATE Categories  SET category_name ='"+category_name+"' ,category_description='"+category_description+"' ,category_image ='"+category_image +"'where category_name='"+category_name+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "category_name":row[0],
            "category_description": row[1],
            "category_image": row[2],
    

           

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response



@app.route('/Delete_Categories', methods=['GET'])
def Delete_Categories():
     #query parameters
    category_name = request.args.get('Cname')
    category_description = request.args.get('Cdescription')
    category_image    = request.args.get('Cimage')
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("DELETE FROM Categories WHERE  category_name='"+category_name+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "category_name":row[0],
            "category_description": row[1],
            "category_image": row[2],
    

           

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response

 # Orders


@app.route('/insert_Orders', methods=['GET'])
def insert_Orders():
     #query parameters
    customer_id = request.args.get('customer_id')
    order_date = request.args.get('order_date')
    total_amount    = request.args.get('total_amount')
    payment_type = request.args.get('payment_type')
    status   = request.args.get('status')

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("INSERT INTO Orders(customer_id,order_date,payment_type,status) VALUES ('"+customer_id+"','"+order_date+"','"+payment_type+"','"+status+"')")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "order_date": row[1],
            "total_amount": row[2],
            "payment_type": row[3],
            "status": row[4]

           

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response


@app.route('/insert_Orders2', methods=['POST'])
def insert_Orders2():
     #query parameters
    customer_id = request.form['customer_id']
    order_date = request.form['order_date']
    total_amount    = request.form['total_amount']
    payment_type = request.form['payment_type']
    status   = request.form['status']

    conn = sqlite3.connect('Cafe.db')
    sql = f"INSERT INTO Orders(customer_id,order_date,payment_type,status) VALUES ('{customer_id}','{order_date}','{payment_type}','{status}')"
    cursor = conn.execute(sql)
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "order_date": row[1],
            "total_amount": row[2],
            "payment_type": row[3],
            "status": row[4]

           

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response





@app.route('/select_Orders', methods=['GET'])
def select_Orders():
     #query parameters
    customer_id = request.args.get('customer_id')
    order_date = request.args.get('order_date')
    total_amount    = request.args.get('total_amount')
    payment_type = request.args.get('payment_type')
    status   = request.args.get('status')

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select orders.order_id,orders.customer_id,customers.frist_name,customers.phone_number,orders.order_date,orders.total_amount,order_details.quantity,products.product_name from customers inner join orders on customers.customer_id = orders.customer_id inner join order_details  on orders.order_id = order_details.order_id inner join products on order_details.prodcuct_id = products.product_id where customers.customer_id ='"+customer_id+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "order_id":row[0],
            "customer_id": row[1],
            "frist_name": row[2],
            "phone_number": row[3],
            "order_date": row[4],
            "total_amount": row[5],
            "quantity": row[6],
            "product_name": row[7],



           

        }
        mylist.append(mydict)

    return mylist

@app.route('/selectall_Orders', methods=['GET'])
def selectall_Orders():
     #query parameters
 

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select distinct customers.customer_id,customers.frist_name,orders.order_id,categories.category_name,products.product_name,order_details.quantity,orders.order_date,orders.payment_type,orders.total_amount,orders.status from customers inner join orders on customers.customer_id = orders.customer_id inner join order_details on orders.order_id = order_details.order_id inner join products on order_details.prodcuct_id = products.product_id inner join categories on products.category_id = categories.category_id")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "frist_name": row[1],
            "order_id": row[2],
            "category_name": row[3],
            "product_name": row[4],
            "quantity": row[5],
            "order_date": row[6],
            "payment_type": row[7],
            "total_amount": row[8],
            "status": row[9],

            

           

        }
        mylist.append(mydict)

    return mylist


@app.route('/Update_Orders', methods=['GET'])
def Update_Orders():

    customer_id = request.args.get('customer_id')
    order_date = request.args.get('order_date')
   # total_amount    = request.args.get('total_amount')
    payment_type = request.args.get('payment_type')
    status   = request.args.get('status')

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("UPDATE Orders  SET customer_id ='"+customer_id+"' , order_date='"+ order_date+"' ,payment_type ='"+payment_type +"', status  ='"+ status +"' where customer_id ='"+customer_id+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "order_date": row[1],
            "total_amount": row[2],
            "payment_type": row[3],
            "status": row[4]

           

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response
   


@app.route('/Update_Orderdet', methods=['GET'])
def Update_Orderdet():

    prodcuct_id= request.args.get('product_id')
    quantity= request.args.get('quantity')
    item_notes= request.args.get('item_notes')
    item_discount = request.args.get('item_discount')
    item_price = request.args.get('item_price')
    item_status = request.args.get('item_status')

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("UPDATE order_details  SET prodcuct_id ='"+prodcuct_id+"' ,  quantity='"+  quantity+"' , item_notes ='"+ item_notes +"',item_discount ='"+item_discount +"',item_price  ='"+  item_price +"',item_status  ='"+  item_status +"' where prodcuct_id ='"+prodcuct_id+"'")
    conn.commit()
    mylist = []

    return "success"




@app.route('/Delete_Orders', methods=['GET'])
def Delete_Order():

    customer_id = request.args.get('customer_id')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("DELETE FROM Orders WHERE  customer_id='"+customer_id+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
           
            

        }
        mylist.append(mydict)
        
        print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response
    
@app.route('/Delete_Ordersdet', methods=['GET'])
def Delete_Orders():

    order_id = request.args.get('order_id')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("DELETE FROM Order_details WHERE  order_id='"+order_id+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "order_id":row[0],
           
            

        }
        mylist.append(mydict)
        
        print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response


@app.route('/insert_Admin', methods=['GET'])
def insert_Admin():
     #query parameters
    Username = request.args.get('User')
    Password = request.args.get('Pass')
    phone_number    = request.args.get('phone_number')
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("INSERT INTO Admin(Username,Password,phone_number) VALUES ('"+Username+"','"+Password+"','"+phone_number+"')")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            " Username":row[0],
            "Password": row[1],
            "phone_number": row[2]
            

        }
        mylist.append(mydict)
        
        print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response


@app.route('/select_Admin', methods=['GET'])
def select_Admin():
     #query parameters
    Username = request.args.get('User')
    Password = request.args.get('Pass')
    phone_number    = request.args.get('phone_number')
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select * from Admin where Username ='"+Username+"' and Password ='"+Password+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "Username":row[0],
            "Password": row[1],
            "phone_number": row[2],
            

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response


@app.route('/Delete_Admin', methods=['GET'])
def Delete_Admin():
     #query parameters
    Username = request.args.get('User')
    Password = request.args.get('Pass')
    phone_number    = request.args.get('phone_number')
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("DELETE FROM Admin WHERE Password='"+Password+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            " Username":row[0],
            "Password": row[1],
            "phone_number": row[2]
            

        }
        mylist.append(mydict)
        
        print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response



# features for Customers

# Create & Login Customers

@app.route('/Create_Customers', methods=['GET'])
def Create_Customers():
     #query parameters
    frist_name = request.args.get('Fname')
    last_name = request.args.get('Lname')
    email     = request.args.get('email')
    phone_number     = request.args.get('phone')
    address          = request.args.get('address')
    city          = request.args.get('city')
    state          = request.args.get('state')
    postal_code         = request.args.get('code')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("INSERT INTO Customers(frist_name,last_name,email,phone_number,address,city,state,postal_code) VALUES ('"+frist_name+"','"+last_name+"','"+email +"','"+ phone_number+"','"+address +"','"+city+"','"+state+"','"+postal_code+"')")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "frist_name": row[1],
            "last_name": row[2],
            "email": row[3],
            "phone_number": row[4],
            "address": row[5],
            "city": row[6],
            "state": row[7],
            "postal_code": row[8],

        }
        mylist.append(mydict)

    return mylist



@app.route('/Login_Customers', methods=['GET'])
def Login_Customers():
     #query parameters
    email = request.args.get('email')
    postal_code = request.args.get('postal_code')

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("SELECT * FROM Customers where email='"+email+"' and postal_code='"+postal_code+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0],
            "frist_name": row[1],
            "last_name": row[2],
            "email": row[3],
            "phone_number": row[4],
            "address": row[5],
            "city": row[6],
            "state": row[7],
            "postal_code": row[8],

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response


# browse Products

@app.route('/browse', methods=['GET'])
def browse():
     #query parameters
    category_name = request.args.get('Cname')
   
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select categories.category_name,Products.product_name,Products.description,Products.image,Products.price from categories inner join Products on categories.category_id = Products.category_id where categories.category_name = '"+category_name+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "category_name":row[0],
            "product_name": row[1],
            "description": row[2],
            "price": row[3],
            "image": row[4],

           

        }
        mylist.append(mydict)

    return mylist


# برای آپدیت و نشون دادن پروفایل

@app.route('/up_id', methods=['GET'])
def up_id():
    # for insert
    postal_code = request.args.get('code')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select customer_id from customers where postal_code = '"+postal_code+"'")
    mystring = ""
    for row in cursor:

       
       
        mystring=mystring+str(row[0]) + "," 
      




      

    return mystring





@app.route('/prof', methods=['GET'])
def prof():
     #query parameters
    frist_name = request.args.get('name')
 

    
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("UPDATE Update_prof set postal_code = '"+frist_name+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "frist_name":row[0],
       

          

            

           

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response


@app.route('/prof2', methods=['GET'])
def prof2():
     #query parameters
    customer_id = request.args.get('customer_id')
 

    
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("UPDATE Update_prof set customer_id = '"+customer_id+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "customer_id":row[0]
       

          

            

           

        }
        mylist.append(mydict)

    print(mylist) 
    response = {"status": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status']="success"
        return response




@app.route('/prof_select', methods=['GET'])
def prof_select():
     #query parameters
    postal_code = request.args.get('code')
   
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select * from Update_prof")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "postal_code":row[0]
            

           

        }
        mylist.append(mydict)

        print(mylist) 
        response = {"status":"failure" }
    if len(mylist) == 0:
        return  response
    else:
        response['status']= row[0]
        return response


@app.route('/products_cate', methods=['GET'])
def products_cate():
     #query parameters
    
   
    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select categories.category_name,products.product_name,products.description,products.image from categories inner join products on categories.category_id = products.category_id")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "category_name":row[0],
            "product_name":row[1],
            "description":row[2],
            "image":row[3],
            
            

           

        }
        mylist.append(mydict)

         

    return mylist




@app.route('/order_det', methods=['GET'])
def order_det():
     #query parameters
    prodcuct_id= request.args.get('product_id')
    quantity= request.args.get('quantity')
    item_notes= request.args.get('item_notes')
    item_discount = request.args.get('item_discount')
    item_price = request.args.get('item_price')
    item_status = request.args.get('item_status')


    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("insert into order_details(prodcuct_id,quantity,item_notes,item_discount,item_price,item_status ) VALUES('"+prodcuct_id+"','"+quantity+"','"+item_notes+"','"+item_discount+"','"+item_price+"','"+item_status+"')")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "prodcuct_id":row[0],
            "quantity":row[1],
            "item_notes":row[2],
            " item_discount":row[3],
            " item_price":row[4]

            

           

        }
        
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response
        return 


@app.route('/s', methods=['GET'])
def s():
     #query parameters
    product_id= request.args.get('product_id')
    quantity= request.args.get('quantity')
    item_notes= request.args.get('item_notes')
    item_discount = request.args.get('item_discount')
    

    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("update order_details set item_total = order_details.quantity * order_details.item_price - order_details.item_discount ")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
            "product_id":row[0],
            "quantity":row[1],
            "item_notes":row[2],
            " item_discount":row[3],
            " item_price":row[4],
            "item_total":row[5],
            "item_status":row[6]

            

           

        }
        
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response
        return 



@app.route('/ss', methods=['GET'])
def ss():
    # for insert

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select price from products")
    mystring = ""
    for row in cursor:

       
        mystring=mystring+str(row[0]) + ":"
      

    return mystring


@app.route('/show', methods=['GET'])
def show():
    # for insert
    postal_code= request.args.get('postal_code')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select frist_name,customer_id from customers where postal_code = '"+postal_code+"'")
    mystring = ""
    for row in cursor:

       
       
        mystring=mystring+str(row[0]) + ":" 
        mystring=mystring+str(row[1]) + ":" 


      

    return mystring


@app.route('/show2', methods=['GET'])
def show2():
    # for insert
   # postal_code= request.args.get('postal_code')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select customer_id from update_prof")
    mystring = ""
    for row in cursor:

       
       
        mystring=mystring+str(row[0]) + ":" 
       


      

    return mystring

@app.route('/brow', methods=['GET'])
def brow():
    # for insert



    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select product_name from products")
    mystring = ""
    for row in cursor:

       
       
        mystring=mystring+str(row[0]) + ":" 

      

    return mystring



@app.route('/showpro', methods=['GET'])
def showpro():
    # for insert
    product_name= request.args.get('product_name')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select categories.category_name,products.product_name,products.description,products.image from categories inner join products on categories.category_id = products.category_id where product_name = '"+product_name+"'")
    mystring = ""
    for row in cursor:

       
       
        mystring=mystring+str(row[0]) + "-" 
        mystring=mystring+str(row[1]) + "-" 
        mystring=mystring+str(row[2]) + "-" 
        mystring=mystring+str(row[3]) + "-" 



      

    return mystring



@app.route('/up', methods=['GET'])
def up():
    # for insert
    customer_id= request.args.get('id')


    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select orders.order_id,orders.customer_id,sum(order_details.item_total) as total_amount from orders inner join order_details on orders.order_id = order_details.order_id group by orders.customer_id having orders.customer_id ='"+customer_id+"'")
    mystring = ""
    for row in cursor:

       
       
        mystring=mystring+str(row[2]) + "," 
      




      

    return mystring


@app.route('/ordertotal', methods=['GET'])
def ordertotal():
     #query parameters
  
    total = request.args.get('total')
    customer_id = request.args.get('id')

    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("update orders set total_amount = '"+total+"' where customer_id ='"+customer_id+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
             "customer_id":row[0],
            "order_date": row[1],
            "total_amount": row[2],
            "payment_type": row[3],
            "status": row[4]
  

            

           

        }
        
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response



@app.route('/delete_show', methods=['GET'])
def delete_show():
    # for insert



    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("select order_id,orders.customer_id,customers.frist_name from orders inner join customers on orders.customer_id = customers.customer_id")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
             "order_id":row[0],
             "customer_id": row[1],
             "frist_name": row[2],
     
  

            

           

        }
        mylist.append(mydict)

         

    return mylist
       
        
@app.route('/upsta', methods=['GET'])
def upsta():
     #query parameters
  
    status = request.args.get('status')
    customer_id = request.args.get('id')

    

    conn = sqlite3.connect('Cafe.db')
    cursor = conn.execute("update orders set status = '"+status+"'")
    conn.commit()
    mylist = []
    for row in cursor:
        mydict = {
             "customer_id":row[0],
            "order_date": row[1],
            "total_amount": row[2],
            "payment_type": row[3],
            "status": row[4]
  

            

           

        }
        
        mylist.append(mydict)

    print(mylist) 
    response = {"status1": "failure"}
    if len(mylist) == 0:
        return  response
    else:
        response['status1']="success"
        return response

      

    







app.run(host='0.0.0.0', port=5000)