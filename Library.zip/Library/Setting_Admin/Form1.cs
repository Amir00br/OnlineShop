﻿namespace Setting_Admin;
using System.Net.Http;
using System.Net.Http.Json;


public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }
    public class Admin
    {
        public string status { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string phone_number { get; set; }
       
    }

    private async void button1_Click(object sender, EventArgs e)
    {
        
        HttpClient client = new HttpClient();

        string user = textBox1.Text;
        string pass = textBox2.Text;
        string phone = textBox4.Text;
        string url = "http://127.0.0.1:5000/insert_Admin?User=" + user + "&Pass=" + pass + "&phone_number=" + phone;
        var httpResponse = await client.GetFromJsonAsync<Admin>(url);
        if (httpResponse.status == "success")
        {
           
            MessageBox.Show("!خطا");
        }
        else
        {
            MessageBox.Show("ثبت شد");

        }


       

    }

    private async void button2_Click(object sender, EventArgs e)
    {
        HttpClient client = new HttpClient();

        string user = textBox5.Text;
        string pass = textBox6.Text;

        string url = "http://127.0.0.1:5000/Delete_Admin?Pass=" + pass;
        var httpResponse2 = await client.GetFromJsonAsync<Admin>(url);
        if (httpResponse2.status == "success")
        {

            MessageBox.Show("!خطا");
        }
        else
        {
            MessageBox.Show("ثبت شد");
            
        }
    }
}